import React from "react";

const Footer = () => {
  return (
    <div
      className="container-fluid navbar  navbar-expand-lg navbar-dark"
      style={{ backgroundColor: "rgb(159 173 187)" }}
    >
      <ul className="navbar-nav mx-auto py-2 text-white">
        copy@Automated System For Material Return From Customer
      </ul>
    </div>
  );
};

export default Footer;
